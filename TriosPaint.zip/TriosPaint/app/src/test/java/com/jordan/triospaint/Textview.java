package com.jordan.triospaint;

public enum Textview {
}
