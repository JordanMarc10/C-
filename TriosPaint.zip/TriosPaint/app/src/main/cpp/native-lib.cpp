#include <jni.h>
#include <string>
#include <bitset>
#include <stdio.h>
#include <jni.h>
using namespace std;

extern "C"
JNIEXPORT jstring JNICALL
Java_com_jordan_triospaint_MainActivity5_dollar1(JNIEnv *env, jobject thiz) {
    // TODO: implement dollar1()
    float can;
    int num,num2;


    if (can < 6){
        num = 0;
        num++;
        num * num2;

    }else {
        num * num2;
    }
    string doublenum = to_string(num+num2);
    return env->NewStringUTF(doublenum.c_str());
}