package com.jordan.triospaint;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class Splash extends AppCompatActivity {

    ImageView Splash;
    Handler first = new Handler();
    Button next,enter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        Splash = findViewById(R.id.imageView);
        next = findViewById(R.id.button);
        enter = findViewById(R.id.button9);

        Intent j = new Intent(this,MainActivity.class);
        startActivity(j);

        first.postDelayed(new Runnable(){
            @Override
            public void run(){
                startActivity(j);
            }
        }, 5000);



        }
        public void next1(View v){

        Intent next = new Intent(this,MainActivity.class);
        startActivity(next);
    }
        public void next2(View v){

        Intent site = new Intent(this,MainActivity.class);
        startActivity(site);
        }
}