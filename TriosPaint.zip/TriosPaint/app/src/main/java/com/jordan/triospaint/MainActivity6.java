package com.jordan.triospaint;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity6 extends AppCompatActivity {

    TextView line;
    ImageView one;
    Button paint,paint2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);

        line = findViewById(R.id.mutliline3);
        one = findViewById(R.id.imageView2);

        paint = findViewById(R.id.button7);
        paint2 = findViewById(R.id.button14);
    }

    public void C(View v){
        Intent cost = new Intent(this,MainActivity4.class);
        startActivity(cost);
    }
    public void much(View v){
        Intent next = new Intent(this,MainActivity4.class);
        startActivity(next);
    }
}