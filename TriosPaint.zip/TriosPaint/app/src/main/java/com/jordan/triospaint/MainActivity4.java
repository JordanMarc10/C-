package com.jordan.triospaint;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.accessibility.AccessibilityEventSource;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity4 extends AppCompatActivity {

    EditText note1,note2,note3,note4;
    Button first,last,map,video,send,video1,map1,land;
    TextView title,b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        title = findViewById(R.id.textView17);
        b = findViewById(R.id.textView6);


    note1 = findViewById(R.id.TextMultiLine);
    note2 = findViewById(R.id.TextEmailAddress);
    note3 = findViewById(R.id.EmailAddress);
    note4 = findViewById(R.id.TextMultiLine1);

    first = findViewById(R.id.button5);
    last = findViewById(R.id.button2);
    send = findViewById(R.id.button3);
    land = findViewById(R.id.button4);


    map = findViewById(R.id.ActionButton2);
    map1 = findViewById(R.id.Actionbutton2);
    video = findViewById(R.id.ActionButton3);
    video1 = findViewById(R.id.ActionButton4);

    }
    public void send(View v){

        String mail = note2.getText().toString();
        String state = note1.getText().toString();
        Toast.makeText(this, "Users name" + mail + state, Toast.LENGTH_LONG).show();

    }

    public void call(View v){

        Intent phone = new Intent(Intent.ACTION_CALL);
        phone.setData(Uri.parse("tel:1647-923-8711"));
        startActivity(phone);

    }
    public void video(View v){

        Intent movie = new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.youtube.com/watch?v=CRXCB_3gLok"));
        startActivity(movie);
    }

    public void map(View v){

        Intent mapView = new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.ca/maps/search/map/@43.7173961,-79.5654063,12z/data=!3m1!4b1"));
     startActivity(mapView);
    }
}