package com.jordan.triospaint;

import static java.lang.Float.parseFloat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.jordan.triospaint.databinding.ActivityMainBinding;

public class MainActivity5 extends AppCompatActivity {

    static {
        System.loadLibrary("nativeapp2");
    }

    private ActivityMainBinding binding;

    Button first,last,one,two;
    ImageView pic,sec;
    TextView text,view;
    EditText c,m;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        TextView cpp = binding.sampleText;
        cpp.setText(dollar1());
        setContentView(R.layout.activity_main5);

        c = findViewById(R.id.NumberDecimal);
        m = findViewById(R.id.NumberDecimal2);

    first = findViewById(R.id.button11);
    last = findViewById(R.id.button8);
    one = findViewById(R.id.button13);
    two = findViewById(R.id.button12);

    pic = findViewById(R.id.imageView3);
    sec = findViewById(R.id.imageView7);
    text = findViewById(R.id.textView9);
    view = findViewById(R.id.textView15);
    }

        public void begin(View v){

        Intent back = new Intent(this,MainActivity.class);
        startActivity(back);
        }

        public void contact1(View v){

        Intent contact = new Intent(this,MainActivity4.class);
        startActivity(contact);
        }

        public void main(View v){

        Intent first = new Intent(this,MainActivity.class);
        startActivity(first);
        }

        public void contact2(View v){

        Intent page = new Intent(this,MainActivity4.class);
        startActivity(page);
        }
        public void calculate(View v)
        {

        view.setText(new String(dollar1()));
    }

        public native String dollar1();
}