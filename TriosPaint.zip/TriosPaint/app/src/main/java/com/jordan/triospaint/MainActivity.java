package com.jordan.triospaint;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.jordan.triospaint.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    Button first,draw;
    ImageView k, b, c;
    TextView text,print;

    // Used to load the 'triospaint' library on application startup.
    static {
        System.loadLibrary("triospaint");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        com.jordan.triospaint.databinding.ActivityMainBinding binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        first = findViewById(R.id.button6);

        k = findViewById(R.id.imageView5);
        b = findViewById(R.id.imageView6);
        c = findViewById(R.id.imageView4);

        text = findViewById(R.id.sample_text);
        print = findViewById(R.id.textView4);
        draw = findViewById(R.id.button10);
        // Example of a call to a native method

    }

    public void history(View v){
        Intent paint = new Intent(this,MainActivity6.class);
        startActivity(paint);
    }
    public void move(View v){
        Intent next = new Intent(this,MainActivity6.class);
        startActivity(next);
    }
}